#define DIM 100
void leer(int matriz[][DIM], int f, int c);
void mostrar(int matriz[][DIM], int f, int c);
void rotar(int matriz[][DIM], int c, int k, int n);
