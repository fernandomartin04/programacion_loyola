int factorial(int n);
int combinatorio(int n, int k);
