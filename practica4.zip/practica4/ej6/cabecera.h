void introducir(int v[], int n);
void mostrar(int v[], int n);
float suma(int v[], int n);
float media(int v[], int n);
float varianza(int v[], int n);
void max(int v[], int n);
void min(int v[], int n);
