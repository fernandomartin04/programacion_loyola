struct complejo{
	float real;
	float im;
};


void leer(complejo v[], int num);
void mostrar(complejo v[], int num);
void suma(complejo v[], int num, float sum[]);
void media(complejo v[], int num, float sum[], float med[]);
