void mostrar(int v[], int n);
void invertir(int v[], int n);
