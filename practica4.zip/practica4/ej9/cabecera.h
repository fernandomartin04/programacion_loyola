int anadir(int v[], int n, int control);
int eliminar(int v[], int n, int control);
void mostrar(int v[], int n, int control);
void divisores(int v[], int n, int control);
