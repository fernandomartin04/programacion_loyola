#define DIM 100
void leer(int matriz[][DIM], int f, int c);
void mostrar(int matriz[][DIM], int f, int c);
void intercambiar(int matriz[][DIM], int f, int c, int fila1, int fila2);

