void potencia(int b, int e, int n);
