void introducir(int v[], int n);
void mostrar(int v[], int n);
void evaluar(int v[], int n, int x);
