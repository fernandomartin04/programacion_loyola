int primo(int num);
void print(int num, int a, int b);
