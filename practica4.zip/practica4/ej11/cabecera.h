#define DIM 100
void leer(int matriz[][DIM], int f, int c);
void mostrar(int matriz[][DIM], int f, int c);
void mostrarV(int v[], int c);
void media(int matriz[][DIM], int f, int c, int v[]);

