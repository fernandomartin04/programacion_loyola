#define DIM 100
void leer(int matriz[][DIM], int f, int c);
void mostrar(int matriz[][DIM], int f, int c);
void buscar(int matriz[][DIM], int f, int c, int n, int v[]);
