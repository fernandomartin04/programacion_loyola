#include <iostream>
using namespace std;

long int funcionRecursiva(int n);
long int funcionIterativa(int n);
