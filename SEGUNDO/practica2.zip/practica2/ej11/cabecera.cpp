#include "cabecera.h"
#include <iostream>
#include <struct>
using namespace std;
