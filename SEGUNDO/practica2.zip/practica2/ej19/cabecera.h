#include <iostream>
using namespace std;

struct resultado {
    int S; 
    int R; 
};

resultado divisionNF(int A, int B); 
resultado divisionF(int A, int B); 
resultado divisionI(int A, int B);  
