#include "cabecera.h"

int main() {
	string v1[] = {"hola", "adiós", "bienvenido", "ok"};
	cout << funcionNoFinal(v1, 4) << endl;
}