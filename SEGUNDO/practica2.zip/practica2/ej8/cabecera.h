#include <string>
#include <iostream>
using namespace std;

string funcionNoFinal(const string *v, int n);
string funcionFinal(const string *v, int n);
string funcionI(const string *v, int n);