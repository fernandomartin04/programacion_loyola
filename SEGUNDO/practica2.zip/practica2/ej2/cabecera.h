#include <cmath>
#include <iostream>
using namespace std;

float funcionNoFinal(float *v, int n);
float funcionFinal(float *v, int n);
float funcionIterativa(float *v, int n);