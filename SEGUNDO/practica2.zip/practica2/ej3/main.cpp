#include "cabecera.h"

int main() {
	string h = "Hola Mundo";
	cout << "Funcion No Final: " << funcionNF(h) << endl;
	cout << "Funcion Final: " << funcionF(h) << endl;
	cout << "Funcion Iterativa: " << funcionIterativa(h) << endl;
}