#include <string>
#include <iostream>
using namespace std;

int funcionNF(const string& cad);
int funcionF(const string& cad);
int funcionIterativa(const string& cad);