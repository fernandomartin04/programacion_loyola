#include <list>
#include <iostream>
using namespace std;

bool esPalindromo(const string& cad);
bool funcionNoFinal(const string& cad);
bool funcionFinalAux(string cad);
bool funcionFinal(const string& cad);
bool funcionIterativa(const string& cad);