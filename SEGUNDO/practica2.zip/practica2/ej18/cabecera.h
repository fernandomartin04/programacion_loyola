#include <iostream>
using namespace std;

struct resultado {
    int suma;       
    int nImpares;   
    int minimo;     
};

resultado funcionNoFinal(int n);
resultado funcionFinal(int n);
resultado funcionIterativa(int n);
