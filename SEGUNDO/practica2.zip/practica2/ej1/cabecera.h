#include <iostream>
using namespace std;

int funcionNoFinal(int *v, int n);
int funcionFinal(int *v, int n);
int funcionIterativa(int *v, int n);