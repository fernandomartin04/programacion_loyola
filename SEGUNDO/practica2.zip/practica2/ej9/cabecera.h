#include <list>
#include <iostream>
using namespace std;

bool esPerfecto(int n);
bool funcionNoFinal(int *v, int n);
bool funcionFinalAux(int *v, int n, bool a);
bool funcionFinal(int *v, int n);
bool funcionIterativa(int *v, int n);