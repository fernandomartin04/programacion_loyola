#include <iostream>
using namespace std;

string invertir(const string& cad, int i);
string funcionNoFinal(const string& cad);
string funcionNoFinalAux(const string& cad, int i, string cadAux, int mitad);
string funcionFinal(const string& cad);
string funcionIterativa(const string& cad);