#include<iostream>
#include <cstdlib>
using namespace std;

int main() {
	srand((unsigned)time(NULL));

	int n;
	n=rand()%33;
	cout << n << endl;

}
